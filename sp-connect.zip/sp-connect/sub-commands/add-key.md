# Add an API Key to Doppler

## Pre-check: Doppler connected?

```bash
doppler me 2>/dev/null >/dev/null
```

If not connected:
> Doppler isn't set up yet. Run `/sp-connect doppler` first to connect your Key Vault, then come back here.

Stop.

## Parse the key name

The key name is passed as an argument: `/sp-connect add-key STRIPE_KEY`

If no name provided, ask:
> What do you want to call this key? Use ALL_CAPS with underscores — for example: `STRIPE_KEY`, `OPENAI_API_KEY`, `REPLICATE_TOKEN`.

Validate the name:
- Must match `^[A-Z][A-Z0-9_]*$`
- If not: suggest a fix. Example: "I'd recommend `STRIPE_KEY` instead of `stripe-key`. Key names should be ALL_CAPS with underscores."

## Check for existing key

```bash
doppler secrets get <NAME> --plain >/dev/null 2>&1 && echo "EXISTS" || echo "NEW"
```

If exists:
> A key called `<NAME>` already exists (I won't show the value). Replace it with a new one?

If no → stop.

## Collect the value

Ask:
> Paste the key value. I won't show it or log it anywhere.

**SECURITY: Never echo, log, or display the key value in any output.**

## Validate format (if known service)

Check the key name against known patterns:

| Key name pattern | Expected prefix | Service |
|-----------------|----------------|---------|
| STRIPE* | `rk_live_`, `sk_live_`, `rk_test_`, `sk_test_` | Stripe |
| REPLICATE* | `r8_` | Replicate |
| OPENAI* | `sk-` | OpenAI |
| ANTHROPIC* | `sk-ant-` | Anthropic |
| MAILERLITE* | (any long string) | MailerLite |
| CLOUDFLARE* | (any long string) | Cloudflare |
| SUPABASE* | `eyJ` (JWT) or `sbp_` | Supabase |
| GITHUB* | `ghp_`, `gho_`, `github_pat_` | GitHub |
| NOTION* | `ntn_`, `secret_` | Notion |

If the value doesn't match the expected pattern for a recognized service:
> This doesn't look like a typical [Service] key (those usually start with `[prefix]`). Use it anyway?

If the key name doesn't match any known pattern, skip validation.

## Store in Doppler

```bash
doppler secrets set <NAME> "<VALUE>" --silent
```

**SECURITY: The VALUE must be properly quoted. Never let it appear in shell history or logs.**

## Verify (length only)

```bash
doppler secrets get <NAME> --plain 2>/dev/null | wc -c | tr -d ' '
```

Confirm the character count is reasonable (not 0).

## Done

> ✅ `<NAME>` saved to your Key Vault. It'll be available in your next Claude Code session automatically.
>
> To see all your stored keys: `/sp-connect list-keys`

## Log (no values)

```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.add-key  $NAME  success" >> ~/.claude/sp-config/audit.log
```
