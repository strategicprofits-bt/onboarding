# Remove a Connection or Key

## Parse the argument

The name is passed as: `/sp-connect remove <name>`

If no name provided, ask:
> What do you want to remove? You can remove:
> - An MCP server connection (e.g., `sp-shared`, `ghl`)
> - A Doppler secret (e.g., `STRIPE_KEY`)
>
> Which one?

## Determine type

Check if the name matches an MCP server:
```bash
claude mcp list 2>/dev/null | grep -q "<name>"
```

Check if it matches a Doppler secret (uppercase pattern):
```bash
doppler secrets get <name> --plain 2>/dev/null >/dev/null
```

- If MCP server → MCP removal flow
- If Doppler secret → secret deletion flow
- If both match → ask: "I found both an MCP server and a Doppler secret called `<name>`. Which do you want to remove?"
- If neither → "I don't see a connection or secret called `<name>`. Run `/sp-connect status` to see what's connected."

## Confirm before removal

**Always confirm destructive actions:**

For MCP servers:
> Remove the `<name>` MCP connection? You'll need to re-add it with `/sp-connect <sub-command>` to use it again. Confirm?

For Doppler secrets:
> Delete the secret `<name>` from your Key Vault? This can't be undone. Confirm?

Wait for confirmation. If they say no, stop.

## Execute removal

### MCP server
```bash
claude mcp remove <name>
```

Verify it's gone:
```bash
claude mcp list 2>/dev/null | grep -q "<name>" && echo "STILL_PRESENT" || echo "REMOVED"
```

### Doppler secret
```bash
doppler secrets delete <name> --yes
```

## Done

> ✅ `<name>` removed.

For MCP servers, add:
> Restart Claude Desktop for this to take effect.

## Log

```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.remove  $NAME  success" >> ~/.claude/sp-config/audit.log
```
