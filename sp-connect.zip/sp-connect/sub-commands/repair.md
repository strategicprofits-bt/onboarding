# Repair Connections

Run verification on all connections and attempt auto-fix for anything broken.

## Step 1: Run all checks silently

```bash
# SP Shared
SP_STATUS="unknown"
if claude mcp list 2>/dev/null | grep -q "sp-shared"; then
  SP_STATUS="connected"
else
  SP_STATUS="missing"
fi

# GHL
GHL_STATUS="unknown"
if claude mcp list 2>/dev/null | grep -q "ghl"; then
  GHL_STATUS="connected"
else
  GHL_STATUS="missing"
fi

# Doppler
DOPPLER_STATUS="unknown"
if doppler me 2>/dev/null >/dev/null; then
  if doppler configs current 2>/dev/null >/dev/null; then
    DOPPLER_STATUS="connected"
  else
    DOPPLER_STATUS="logged_in_no_project"
  fi
else
  if command -v doppler >/dev/null 2>&1; then
    DOPPLER_STATUS="installed_not_logged_in"
  else
    DOPPLER_STATUS="not_installed"
  fi
fi
```

## Step 2: Attempt auto-fix for broken items

### SP Shared — broken

If SP_STATUS is "connected" but a test call returns 401:
> Your SP Shared connection is rejecting your key. The key may have expired or been rotated. Want to reconnect?

If yes → hand off to `sub-commands/sp-mcp.md`

If SP_STATUS is "missing":
> SP Shared isn't connected. Want to set it up now?

If yes → hand off to `sub-commands/sp-mcp.md`

### GHL — broken

If GHL_STATUS is "connected" but a test call fails:
- 401: "Your GHL token is wrong or expired. Create a new Private Integration Token in GHL and reconnect."
- 403: "Your GHL token doesn't have permission for this Location. Check the integration's scope settings."
- Other: show error verbatim

If yes to reconnect → hand off to `sub-commands/ghl.md`

### Doppler — degraded states

**installed_not_logged_in:**
> Doppler is installed but your session has expired. Want me to log you back in?

If yes:
```bash
doppler login
```
Then verify with `doppler me`.

**logged_in_no_project:**
> Doppler is logged in but no project is configured for this directory. Want me to set it up?

If yes → hand off to `sub-commands/doppler.md` starting from Stage 4 (project setup).

**not_installed:**
> Doppler CLI isn't installed. Want me to set up your Key Vault from scratch?

If yes → hand off to `sub-commands/doppler.md` from the beginning.

### .envrc check (if Doppler is connected)

```bash
VAULT_DIR="${VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
if [ -f "$VAULT_DIR/.envrc" ] && grep -q "doppler" "$VAULT_DIR/.envrc"; then
  echo "ENVRC_OK"
else
  echo "ENVRC_MISSING"
fi
```

If missing, recreate:
```bash
echo 'eval "$(doppler secrets download --no-file --format env)"' >> "$VAULT_DIR/.envrc"
```
If direnv is available: `direnv allow "$VAULT_DIR"`

## Step 3: Summary

> **Repair results:**
>
> [for each item checked, show result and action taken]
> - SP Shared: ✅ Connected (no action needed)
> - GHL: 🔧 Reconnected with new token
> - Doppler: 🔧 Re-logged in, session restored
> - .envrc: 🔧 Recreated
>
> [if anything still broken]
> These need your input:
> - [item]: [what to do]

## Log

```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.repair  run  sp=$SP_STATUS ghl=$GHL_STATUS doppler=$DOPPLER_STATUS" >> ~/.claude/sp-config/audit.log
```
