# Connect SP Shared MCP Server

## Pre-check

```bash
claude mcp list 2>/dev/null | grep -q "sp-shared"
```

If `sp-shared` is already listed, tell the owner:
> SP Shared is already connected. Want to reconnect with a different key? (This replaces the existing connection.)

If they say no, stop here — connection is fine.
If they say yes, proceed to remove the old one first:
```bash
claude mcp remove sp-shared
```

## Collect the API key

Ask:
> Paste your Strategic Profits API key. It starts with `sk_sp_` and was emailed to you when you enrolled.

Validate the key format:
- Must match pattern: starts with `sk_sp_` followed by hex characters
- If it doesn't match: "That doesn't look right — SP API keys start with `sk_sp_` followed by a long string of letters and numbers. Check your enrollment email and try again."
- If it has leading/trailing whitespace, trim it silently

## Add the MCP server

Run:
```bash
claude mcp add --transport http \
  --header "Authorization: Bearer <KEY>" \
  --scope user \
  sp-shared \
  https://mcp.strategicprofits.com/mcp
```

Replace `<KEY>` with the actual key value.

If the command fails:
- Show the error verbatim
- Suggest: "The most common cause is a typo in the key. Re-copy from your enrollment email — make sure you get the whole thing including the `sk_sp_` prefix."

## Verify

```bash
claude mcp list 2>/dev/null | grep "sp-shared"
```

If `sp-shared` appears with no error indicator, the connection is registered.

## Hot-test (optional)

If possible, make a test call to the SP server to verify the key works. If the server returns 401, the key is invalid:
> Your key was rejected by the server. It may have been revoked or entered incorrectly. Double-check with your enrollment email, or post in the Strategic Profits community for help.

## Done

> ✅ SP Shared is connected. Close this Code tab and reopen it (or restart Claude Desktop) for the connection to take effect in your current session.
>
> Once you restart, you'll have access to all the shared skills and resources from Strategic Profits.

Log the action:
```bash
mkdir -p ~/.claude/sp-config
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.sp-mcp  add  success" >> ~/.claude/sp-config/audit.log
```
