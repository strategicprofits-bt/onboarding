# Set Up Doppler Key Vault

This is the most complex sub-command. It has 7 stages with checkpoint state saved between each. If the owner abandons mid-flow, they can resume where they left off.

## Resume check

```bash
cat ~/.claude/sp-config/connect-progress.json 2>/dev/null
```

If the file exists and has a `doppler` entry with `status: "in_progress"`, offer to resume:
> Looks like you started Doppler setup earlier and got to the **[stage name]** step. Want to resume from there?

If yes → skip to the saved stage.
If no → start fresh (clear the doppler entry from progress file).

## Stage 1: Account check

Ask:
> Do you already have a Doppler account?

**If no:**
> Open [doppler.com](https://doppler.com) in your browser and create a free account. Use whatever email you prefer — it doesn't need to match anything else.
>
> I'll wait. Type **done** when you're back.

Wait for the owner to confirm.

**If yes:** continue.

Save checkpoint:
```bash
mkdir -p ~/.claude/sp-config
# Update connect-progress.json with doppler.stage = "account-check", status = "in_progress"
```

## Stage 2: CLI install

Check if Doppler CLI is already installed:
```bash
doppler --version 2>/dev/null
```

**If installed:** show version, skip to Stage 3.

**If not installed:** detect OS and install:

### macOS
```bash
brew install dopplerhq/cli/doppler
```
If Homebrew isn't installed:
> Doppler's installer needs Homebrew. Let's install that first:
> ```
> /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
> ```
> After Homebrew installs, I'll install Doppler.

### Windows (via Scoop)
```bash
# Check if Scoop is installed
scoop --version 2>/dev/null || echo "SCOOP_MISSING"
```
If Scoop is missing:
> Doppler's installer needs Scoop. Install it first by running this in PowerShell:
> ```
> Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser; Invoke-RestMethod -Uri https://get.scoop.sh | Invoke-Expression
> ```
> After Scoop installs, I'll install Doppler.

Then:
```bash
scoop bucket add doppler https://github.com/DopplerHQ/scoop-doppler.git
scoop install doppler
```

### Linux
```bash
(curl -Ls --tlsv1.2 --proto "=https" --retry 3 https://cli.doppler.com/install.sh || wget -t 3 -qO- https://cli.doppler.com/install.sh) | sudo sh
```

**Verify installation:**
```bash
doppler --version
```
If this fails, surface the error and stop — don't proceed with a broken CLI.

Save checkpoint: stage = "cli-install"

## Stage 3: Login

Check if already logged in:
```bash
doppler me 2>/dev/null
```

**If logged in:** show the account info and ask:
> You're logged in to Doppler as **[email]**. Continue with this account?

If no → run `doppler logout` first.

**If not logged in:**
```bash
doppler login
```

Tell the owner:
> A browser window is opening. Click **Authorize** to connect Doppler to this machine. Come back here and type **done** when you see the success message in your browser.

**Fallback:** if the browser doesn't open:
> If a browser window didn't open, try this instead:
> ```
> doppler login --no-browser
> ```
> Copy the URL it prints and paste it into your browser manually.

**Verify:**
```bash
doppler me
```
Show the owner their account info to confirm.

Save checkpoint: stage = "login"

## Stage 4: Project setup

Suggest a project name:
> I recommend naming your Doppler project **strategic-profits**. This keeps all your SP-related keys organized. Sound good?

If the owner wants a different name, use theirs (lowercase, kebab-case).

Check if the project exists:
```bash
doppler projects 2>/dev/null | grep -q "<project-name>"
```

**If it exists:**
> Project **<name>** already exists in Doppler. I'll use it.

**If it doesn't exist:**
> The project doesn't exist yet. I'll need you to create it in the Doppler dashboard:
>
> 1. Open [dashboard.doppler.com](https://dashboard.doppler.com)
> 2. Click **Create Project**
> 3. Name it **<suggested-name>**
> 4. Click Create
> 5. Come back here and type **done**

Wait for confirmation, then verify:
```bash
doppler projects | grep -q "<project-name>"
```

**Configure the project for this directory:**
```bash
doppler setup --no-interactive --project <name> --config dev
```

**Verify:**
```bash
doppler configs current
```

Save checkpoint: stage = "project-setup", project_name = "<name>"

## Stage 5: Test key

> I'm going to add a temporary test secret to verify everything works, then delete it.

```bash
doppler secrets set TEST_SP_CONNECT hello-world --silent
```

Read it back:
```bash
doppler secrets get TEST_SP_CONNECT --plain
```

If the value is "hello-world", it works. Delete the test:
```bash
doppler secrets delete TEST_SP_CONNECT --yes
```

If anything fails, surface the error:
> Something went wrong with Doppler. The error was: [error]
>
> This usually means the project or config isn't set up correctly. Run `doppler configs current` and make sure it shows your project and the `dev` config.

Save checkpoint: stage = "test-key"

## Stage 6: Persistence

Set up environment variable injection so Claude always has access to Doppler secrets.

### Option A: direnv (preferred if available)

```bash
which direnv 2>/dev/null
```

If direnv is installed, create or append to `.envrc` in the vault directory:
```bash
VAULT_DIR="<vault_path>"
echo 'eval "$(doppler secrets download --no-file --format env)"' >> "$VAULT_DIR/.envrc"
direnv allow "$VAULT_DIR"
```

### Option B: Shell profile (fallback)

If direnv is not available, add to the user's shell profile:
```bash
# Detect shell
SHELL_RC="$HOME/.zshrc"
[ -f "$HOME/.bashrc" ] && [ ! -f "$HOME/.zshrc" ] && SHELL_RC="$HOME/.bashrc"

# Add Doppler env loading (only if not already present)
grep -q "doppler secrets" "$SHELL_RC" 2>/dev/null || echo '
# Doppler secrets (added by /sp-connect)
eval "$(doppler secrets download --no-file --format env 2>/dev/null)"' >> "$SHELL_RC"
```

Tell the owner:
> I've set up your system to load Doppler secrets automatically. You may need to restart your terminal or Claude Desktop for this to take effect the first time.

Save checkpoint: stage = "persistence"

## Stage 7: Confirmation

Print summary:
> ✅ Your Key Vault is connected.
>
> **Project:** <name>
> **Config:** dev
> **Secrets stored:** [count, or "none yet — you'll add them as you go"]
>
> From now on, when you need to add an API key, just say:
> `/sp-connect add-key STRIPE_KEY` (or whatever the key is called)
>
> And I'll handle the rest.

Update progress file: doppler.status = "connected", doppler.completed_at = now

Log:
```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.doppler  setup  success  project=<name>  config=dev" >> ~/.claude/sp-config/audit.log
```
