# Connection Status

Show a clean, human-readable summary of all connections.

## Checks to run

Run all three verify scripts and collect results:

```bash
SKILL_DIR="$(dirname "$(dirname "$0")")"

# SP Shared MCP
claude mcp list 2>/dev/null | grep -q "sp-shared" && SP_STATUS="connected" || SP_STATUS="missing"

# GHL MCP
claude mcp list 2>/dev/null | grep -q "ghl" && GHL_STATUS="connected" || GHL_STATUS="missing"

# Doppler
if doppler me 2>/dev/null >/dev/null; then
  DOPPLER_USER=$(doppler me --json 2>/dev/null | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("email") or d.get("name","unknown"))' 2>/dev/null || echo "unknown")
  DOPPLER_PROJECT=$(doppler configs current --json 2>/dev/null | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("project","unknown"))' 2>/dev/null || echo "unknown")
  DOPPLER_CONFIG=$(doppler configs current --json 2>/dev/null | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("config","unknown"))' 2>/dev/null || echo "unknown")
  DOPPLER_COUNT=$(doppler secrets --only-names 2>/dev/null | wc -l | tr -d ' ')
  DOPPLER_STATUS="connected"
else
  DOPPLER_STATUS="missing"
fi
```

## Output format

Present as a clean status report:

```
🔗 Strategic Profits Connections

MCP Servers
  ✅ sp-shared        Connected
  ❌ ghl              Not connected

Built-in Connectors (Claude Desktop)
  ⚠️  Cannot detect from Code tab — check Claude Desktop → Settings → Connectors

Key Vault (Doppler)
  ✅ Logged in as: ben@example.com
  ✅ Project: strategic-profits
  ✅ Config: dev
  ✅ 7 secrets stored
```

Adjust status icons:
- ✅ = connected and working
- ❌ = not connected
- ⚠️ = cannot determine

## Footer

```
Type '/sp-connect list-keys' to see secret names.
Type '/sp-connect repair' if something looks wrong.
Type '/sp-connect' to set up anything that's missing.
```

## Regenerate connections.md

After displaying status, silently regenerate the connections file:
```bash
bash "$(dirname "$(dirname "$0")")/lib/connections-md.sh" "<vault_path>"
```

## Log

```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.status  check  sp=$SP_STATUS ghl=$GHL_STATUS doppler=$DOPPLER_STATUS" >> ~/.claude/sp-config/audit.log
```
