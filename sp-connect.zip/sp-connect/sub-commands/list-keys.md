# List Doppler Secret Names

## Pre-check: Doppler connected?

```bash
doppler me 2>/dev/null >/dev/null
```

If not connected:
> Doppler isn't set up yet. Run `/sp-connect doppler` first.

Stop.

## Get secret names

```bash
doppler secrets --only-names 2>/dev/null
```

## Output

If secrets exist:

```
🔐 Secrets stored in Doppler (values not shown)

  STRIPE_KEY
  REPLICATE_API_TOKEN
  MAILERLITE_KEY
  OPENAI_API_KEY

Total: 4 secrets
```

If no secrets:

```
🔐 No secrets stored yet.

Add your first key with: /sp-connect add-key STRIPE_KEY
```

**SECURITY: Never show secret values. Only names.**

## Log

```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.list-keys  check  success" >> ~/.claude/sp-config/audit.log
```
