# Connect GoHighLevel MCP Server

## Pre-check

```bash
claude mcp list 2>/dev/null | grep -q "ghl"
```

If `ghl` is already listed:
> GHL is already connected. Want to reconnect with different credentials? (This replaces the existing connection.)

If no → stop, connection is fine.
If yes → remove first:
```bash
claude mcp remove ghl
```

## Collect credentials

### Private Integration Token (PIT)

Ask:
> Paste your GoHighLevel Private Integration Token (PIT).
>
> To create one: in GoHighLevel, go to **Settings → Integrations → Private Integrations → Create New**. Give it a name like "Claude" and copy the token.

Validate:
- Must be a non-empty string, at least 20 characters
- If too short: "That looks too short for a GHL token. They're usually a long string of characters. Check that you copied the full token."

### Location ID

Ask:
> Paste your GHL Location ID.
>
> Find it in GoHighLevel: **Settings → Business Profile** (it's listed there), or look at your GHL dashboard URL — the long string after `/location/`.

Validate:
- Should be alphanumeric, roughly 20-30 characters
- If it doesn't match: "That doesn't look like a typical GHL Location ID. They're usually about 24 characters of letters and numbers. Check your GHL dashboard URL."

## Add the MCP server

```bash
claude mcp add --transport http \
  --header "Authorization: Bearer <PIT>" \
  --header "locationId: <LOCATION_ID>" \
  --scope user \
  ghl \
  https://mcp.gohighlevel.com
```

Replace `<PIT>` and `<LOCATION_ID>` with actual values.

**Implementation note:** The GHL MCP URL, header names, and required headers may change. Before running this command, verify the current GHL MCP documentation. If the URL or headers have changed, update this command accordingly and inform the owner.

If the command fails, show the error and suggest re-checking both credentials.

## Verify

```bash
claude mcp list 2>/dev/null | grep "ghl"
```

If listed, attempt a read-only test call (e.g., fetch one contact). Interpret results:
- **Success** → connection works
- **401** → "Your PIT is wrong or expired. Create a new one in GHL and try again."
- **403** → "Your PIT doesn't have permission for this Location. In GHL, check the integration's scope settings — make sure it has access to the Location you specified."
- **Other error** → show verbatim, suggest checking both values

## Done

> ✅ GHL is connected. Close this Code tab and reopen it (or restart Claude Desktop) for the connection to take effect.
>
> Once you restart, you can ask Claude things like "Show me my recent GHL contacts" or "Check my pipeline."

Log:
```bash
mkdir -p ~/.claude/sp-config
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ)  sp-connect.ghl  add  success" >> ~/.claude/sp-config/audit.log
```
