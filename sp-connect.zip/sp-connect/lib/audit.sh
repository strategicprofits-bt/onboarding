#!/bin/bash
# Append to sp-connect audit log
# Usage: bash audit.sh <component> <action> [details]
# Example: bash audit.sh sp-mcp add success
# SECURITY: Never pass secret values as arguments

COMPONENT="${1:-unknown}"
ACTION="${2:-unknown}"
DETAILS="${3:-}"

mkdir -p ~/.claude/sp-config

TIMESTAMP=$(date -u +%Y-%m-%dT%H:%M:%SZ)
echo "$TIMESTAMP  sp-connect.$COMPONENT  $ACTION  $DETAILS" >> ~/.claude/sp-config/audit.log
