# /sp-connect

Connection manager for Strategic Profits program participants. Handles MCP server setup, Doppler key vault configuration, and ongoing connection maintenance.

## Sub-commands

| Command | Purpose |
|---------|---------|
| `/sp-connect` | Interview mode — walks through everything needed |
| `/sp-connect sp-mcp` | Connect SP shared MCP server |
| `/sp-connect ghl` | Connect GoHighLevel MCP server |
| `/sp-connect doppler` | Set up Doppler key vault (account, CLI, login, project) |
| `/sp-connect add-key <NAME>` | Add an API key to Doppler |
| `/sp-connect status` | Show all connection statuses |
| `/sp-connect repair` | Re-verify and auto-fix connections |
| `/sp-connect list-keys` | List Doppler secret names (values hidden) |
| `/sp-connect remove <name>` | Remove a connection or secret |

## Model guidance

This skill is optimized for Sonnet or higher. Haiku is not recommended — state detection and conversational recovery for non-technical users degrade at lower capability tiers.

## File structure

```
sp-connect/
├── SKILL.md              # Router and interview mode
├── sub-commands/          # One .md per sub-command
├── verify/                # Idempotent check scripts (exit 0=OK, 1=broken, 2=unchecked)
├── lib/                   # Shared utilities (shell scripts, JSON registry)
└── README.md              # This file
```

## Update path

Distributed via `sp_sync` from the shared-claude-skills repo. No self-update mechanism — owners get the latest version when they sync.
