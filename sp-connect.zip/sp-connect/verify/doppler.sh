#!/bin/bash
# Verify Doppler connection
# Exit codes: 0=OK, 1=broken, 2=unchecked

if ! command -v doppler >/dev/null 2>&1; then
  echo "doppler CLI not installed"
  exit 1
fi

if ! doppler me 2>/dev/null >/dev/null; then
  echo "doppler: not logged in"
  exit 1
fi

if ! doppler configs current 2>/dev/null >/dev/null; then
  echo "doppler: logged in but no project configured"
  exit 1
fi

echo "doppler: connected"
exit 0
