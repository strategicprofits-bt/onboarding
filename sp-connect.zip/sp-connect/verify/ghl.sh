#!/bin/bash
# Verify GoHighLevel MCP connection
# Exit codes: 0=OK, 1=broken, 2=unchecked

if ! command -v claude >/dev/null 2>&1; then
  echo "claude CLI not found"
  exit 2
fi

if claude mcp list 2>/dev/null | grep -q "ghl"; then
  echo "ghl: connected"
  exit 0
else
  echo "ghl: not found in mcp list"
  exit 1
fi
